#!/bin/bash
HELL=/media/fat/Diablo
MPQ_FILE=${HELL}/diabdat.mpq
DEVILUTIONX=${HELL}/devilutionx
display_help() {
	echo >&2
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
	echo
	echo " ███╗   ███╗██╗███████╗████████╗███████╗██████╗ ██╗  ██╗██╗   ██╗███╗   ██╗"
	echo " ████╗ ████║██║██╔════╝╚══██╔══╝██╔════╝██╔══██╗██║ ██╔╝██║   ██║████╗  ██║"
	echo " ██╔████╔██║██║███████╗   ██║   █████╗  ██████╔╝█████╔╝ ██║   ██║██╔██╗ ██║"
	echo " ██║╚██╔╝██║██║╚════██║   ██║   ██╔══╝  ██╔══██╗██╔═██╗ ██║   ██║██║╚██╗██║"
	echo " ██║ ╚═╝ ██║██║███████║   ██║   ███████╗██║  ██║██║  ██╗╚██████╔╝██║ ╚████║"
	echo " ╚═╝     ╚═╝╚═╝╚══════╝   ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝"
	echo
	echo " https://github.com/misterkun-io/MiSTer_DeViL"
	echo
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
	echo
	[ ! -d ${HELL} ] && echo "   [ERROR] FOLDER NOT FOUND: ${HELL}"
	[ ! -f ${MPQ_FILE} ] && echo "   [ERROR] FILE NOT FOUND: ${MPQ_FILE}"
	echo
	echo "   How to fix and play:"
	echo
	echo "    - Extract contents of \"Arm-DevilutionX_[VERSION].zip\" into the"
	echo "      root of your SD Card."
	echo
	echo "    - Copy \"diabdat.mpq\" from the original game disc or GOG version"
	echo "      to the \"Diablo\" folder on the root of your SD Card."
	echo
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
	echo
	exit 1
}
# Keep the devil at bay - Savegame and Config on the installation folder
export XDG_DATA_HOME=${HELL}
export HOME=${HELL}
# Fix filename as game requires it all lowercase
[ -f ${HELL}/DIABDAT.MPQ ] && { mv ${HELL}/DIABDAT.MPQ ${MPQ_FILE}.tmp; mv ${MPQ_FILE}.tmp ${MPQ_FILE}; }
[ -f ${HELL}/DIABDAT.mpq ] && { mv ${HELL}/DIABDAT.mpq ${MPQ_FILE}.tmp; mv ${MPQ_FILE}.tmp ${MPQ_FILE}; }
[ -f ${HELL}/diabdat.MPQ ] && { mv ${HELL}/diabdat.MPQ ${MPQ_FILE}.tmp; mv ${MPQ_FILE}.tmp ${MPQ_FILE}; }
[ -f ${MPQ_FILE} ] && taskset 03 ${DEVILUTIONX} || display_help
